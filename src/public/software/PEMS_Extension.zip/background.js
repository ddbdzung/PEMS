chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    PEMS_URL: 'https://personal-education-management-system.onrender.com',
    LOCAL_URL: 'http://localhost:3000'
  });
});

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  if (message.message === 'import-data') {
    const { PEMS_URL, LOCAL_URL } = await chrome.storage.sync.get(['PEMS_URL', 'LOCAL_URL'])
    const { data } = message

    try {
      let rawMessageFromPEMS = await fetch(`${PEMS_URL}/import-data`, {
        // let rawMessageFromPEMS = await fetch(`${LOCAL_URL}/import-data`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ data })
      })
      let messageFromPEMS = await rawMessageFromPEMS.json()
      if (messageFromPEMS.message === 'Import data successfully') {
        const response = await chrome.runtime.sendMessage({ message: 'import-successfully' })
      } else {
        const response = await chrome.runtime.sendMessage({ message: 'validation-failed' })
      }
    } catch (e) {
      console.log('error', e)
      const response = await chrome.runtime.sendMessage({ message: 'fail-to-import-data' })
    }
  } else if (message.message === 'drop-data') {
    const { PEMS_URL, LOCAL_URL } = await chrome.storage.sync.get(['PEMS_URL', 'LOCAL_URL'])

    try {
      let rawMessageFromPEMS = await fetch(`${PEMS_URL}/dropDatabase`, {
        // let rawMessageFromPEMS = await fetch(`${LOCAL_URL}/dropDatabase`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
      })
      let messageFromPEMS = await rawMessageFromPEMS.json()
      if (messageFromPEMS.message === 'Drop database successfully') {
        const response = await chrome.runtime.sendMessage({ message: 'drop-data-successfully' })
      }
    } catch (e) {
      console.log('error', e)
      const response = await chrome.runtime.sendMessage({ message: 'fail-to-drop-data' })
    }
  }
})
