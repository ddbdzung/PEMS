/**
 ** https://developer.chrome.com/docs/extensions/reference/scripting/#method-executeScript
 ** Show current tab object in context console
 * @returns {Promise<tab>} currentTab
 */
const logCurrentWindowTab = async () => {
  let [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  })
  await chrome.scripting.executeScript({
    target: {
      tabId: tab.id,
    },
    func: (tab) => {
      // console.log(tab)
    },
    args: [tab]
  })
  return tab
}

let saveData = document.getElementById('save-data')
let fillData = document.getElementById('fill-data')
let firstBtn = document.getElementById('open-data-tab')
let removeBtn = document.getElementById('remove-data')

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  const { PEMS_URL } = await chrome.storage.sync.get(['PEMS_URL'])
  const currentTab = await logCurrentWindowTab()
  await chrome.scripting.executeScript({
    target: {
      tabId: currentTab.id,
    },
    func: (message, PEMS_URL) => {
      if (message.message === 'import-successfully') {
        alert('Import data successfully!', PEMS_URL)
        window.open(PEMS_URL, '_blank');
      } else if (message.message === 'validation-failed') {
        alert('There is something wrong with server!')
      } else if (message.message === 'fail-to-import-data') {
        alert('Something wrong. Please contact service provider for more information!')
      } else if (message.message === 'drop-data-successfully') {
        alert('Drop database successfully')
      }
    },
    args: [message, PEMS_URL]
  })


})

firstBtn.addEventListener('click', async () => {
  let tab = await logCurrentWindowTab()
  await chrome.scripting.executeScript({
    target: {
      tabId: tab.id,
    },
    func: (tab) => {
      window.location.href = 'https://sv.dhcnhn.vn/student/result/examresult'
    },
    args: [tab]
  })
})

// When the button is clicked, inject scripts into current pages
saveData.addEventListener('click', async () => {
  const tab = await logCurrentWindowTab()
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: async () => {
      // Create snippet save data
      (function (console) {
        console.save = function (data, filename) {

          if (!data) {
            console.error('Console.save: No data');
            return;
          }

          if (!filename) {
            filename = 'data.json';
          }

          if (typeof data === 'object') {
            data = JSON.stringify(data, undefined, 4);
          }

          var blob = new Blob([data], { type: 'text/json' }),
            e = document.createEvent('MouseEvents'),
            a = document.createElement('a');

          a.download = filename;
          a.href = window.URL.createObjectURL(blob);
          a.dataset.downloadurl = ['text/json', a.download, a.href].join(':');
          e.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
          a.dispatchEvent(e);
        }
      }(console))
      // --------------------------------------------
      // Crawl data from https://sv.dhcnhn.vn/student/result/examresult
      const table = document.querySelectorAll('.k-panel-mc  div:nth-child(2) tbody tr:not(tr:nth-last-child(1), tr:nth-last-child(2)')
      const data = []
      class Subject {
        constructor(maHP, maIn, tenHP, hocKy, soTinChi, tbKtraTX, diemThi, diemTB) {
          this.maHP = maHP,
            this.maIn = maIn,
            this.tenHP = tenHP,
            this.hocKy = hocKy,
            this.soTinChi = parseInt(soTinChi),
            this.tbKtraTX = parseFloat(tbKtraTX),
            this.diemThi = parseFloat(diemThi),
            this.diemTB = parseFloat(diemTB)
        }
      }
      for (let i of table) {
        const maHP = i.querySelector('td:nth-child(2)').innerText
        const maIn = i.querySelector('td:nth-child(3)').innerText
        const tenHP = i.querySelector('td:nth-child(4)').innerText
        const hocKy = i.querySelector('td:nth-child(5)').innerText
        const soTinChi = i.querySelector('td:nth-child(6)').innerText
        const tbKtraTX = i.querySelector('td:nth-child(7)').innerText
        const diemThi = i.querySelector('td:nth-child(8)').innerText
        const diemTB = i.querySelector('td:nth-child(12)').innerText
        const temp = new Subject(maHP, maIn, tenHP, hocKy, soTinChi, tbKtraTX, diemThi, diemTB)
        data.push(temp)
      }
      if (data.length === 0) {
        alert('Không thể tải file do không có dữ liệu nào đưọc tìm thấy. Vui lòng thực hiện lại theo hướng dẫn!')
        return;
      }

      console.save({ data })
    },
    args: []
  })
})

// Send a message from current tab with crawled data by calling API: https://personal-education-management-system.onrender.com/import-data
fillData.addEventListener('click', async () => {
  const currentTab = await logCurrentWindowTab()
  await chrome.scripting.executeScript({
    target: { tabId: currentTab.id },
    func: async () => {
      // Crawl data from https://sv.dhcnhn.vn/student/result/examresult
      const table = document.querySelectorAll('.k-panel-mc  div:nth-child(2) tbody tr:not(tr:nth-last-child(1), tr:nth-last-child(2)')
      const data = []
      class Subject {
        constructor(maHP, maIn, tenHP, hocKy, soTinChi, tbKtraTX, diemThi, diemTB) {
          this.maHP = maHP,
            this.maIn = maIn,
            this.tenHP = tenHP,
            this.hocKy = hocKy,
            this.soTinChi = parseInt(soTinChi),
            this.tbKtraTX = parseFloat(tbKtraTX),
            this.diemThi = parseFloat(diemThi),
            this.diemTB = parseFloat(diemTB)
        }
      }
      for (let i of table) {
        const maHP = i.querySelector('td:nth-child(2)').innerText
        const maIn = i.querySelector('td:nth-child(3)').innerText
        const tenHP = i.querySelector('td:nth-child(4)').innerText
        const hocKy = i.querySelector('td:nth-child(5)').innerText
        const soTinChi = i.querySelector('td:nth-child(6)').innerText
        const tbKtraTX = i.querySelector('td:nth-child(7)').innerText
        const diemThi = i.querySelector('td:nth-child(8)').innerText
        const diemTB = i.querySelector('td:nth-child(12)').innerText
        const temp = new Subject(maHP, maIn, tenHP, hocKy, soTinChi, tbKtraTX, diemThi, diemTB)
        data.push(temp)
      }
      if (data.length === 0) {
        alert('Không thể tải file do không có dữ liệu nào đưọc tìm thấy. Vui lòng thực hiện lại theo hướng dẫn!')
        return;
      }
      // --------------------------------------------

      let payload = {
        data,
        message: 'import-data',
      }
      const response = await chrome.runtime.sendMessage(payload)
    },
    args: []
  })
})

// Send a message from current tab with crawled data by calling API: https://personal-education-management-system.onrender.com/import-data
removeBtn.addEventListener('click', async () => {
  const currentTab = await logCurrentWindowTab()
  await chrome.scripting.executeScript({
    target: { tabId: currentTab.id },
    func: async () => {
      let payload = {
        message: 'drop-data',
      }
      const response = await chrome.runtime.sendMessage(payload)
    },
    args: []
  })
})
