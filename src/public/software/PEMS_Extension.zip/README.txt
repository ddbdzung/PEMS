Tiếng Việt:
1. Giải nén file zip ra một folder (Extract To "PEMS_Extension")
2. Mở trình duyệt của bạn lên và tìm kiếm <tên trình duyệt>://extensions => Enter
3. Chọn Developer Mode, màn hình hiện ra các tùy chọn
4. Chọn Load unpacked
5. Tìm đến folder PEMS_Extension vừa giải nén khi nãy và Enter
Đã cài đặt thành công, đọc hướng dẫn sử dụng extension đã ghi rõ trên đó